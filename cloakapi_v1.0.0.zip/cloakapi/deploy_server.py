"""
CloakAPI Auto-Deploy Script
يقوم تلقائياً برفع الخادم على GitHub ثم Render.com (مجاناً ودائماً).

الاستخدام:
    python deploy_server.py --github-token YOUR_TOKEN --repo-name cloakapi-server
"""

import os
import sys
import subprocess
import argparse
import json
import requests
import time


def run_command(cmd: str, cwd: str = None) -> tuple[int, str, str]:
    """تشغيل أمر shell والحصول على المخرجات."""
    result = subprocess.run(
        cmd, shell=True, capture_output=True, text=True, cwd=cwd
    )
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def create_github_repo(token: str, repo_name: str) -> str:
    """إنشاء مستودع GitHub جديد وإعادة رابطه."""
    print(f"\n📦 إنشاء مستودع GitHub: {repo_name}...")

    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
    }

    # التحقق من المستخدم
    user_resp = requests.get("https://api.github.com/user", headers=headers)
    if user_resp.status_code != 200:
        raise ValueError("❌ توكن GitHub غير صالح!")
    username = user_resp.json()["login"]
    print(f"   ✅ مستخدم GitHub: {username}")

    # إنشاء المستودع
    repo_data = {
        "name": repo_name,
        "description": "CloakAPI Server — تحويل الكود إلى API محمي",
        "private": False,
        "auto_init": False,
    }

    create_resp = requests.post(
        "https://api.github.com/user/repos",
        headers=headers,
        json=repo_data
    )

    if create_resp.status_code == 422:
        print(f"   ⚠️ المستودع '{repo_name}' موجود مسبقاً. سيتم استخدامه.")
    elif create_resp.status_code != 201:
        raise RuntimeError(f"❌ فشل إنشاء المستودع: {create_resp.text}")
    else:
        print(f"   ✅ تم إنشاء المستودع بنجاح!")

    repo_url = f"https://github.com/{username}/{repo_name}"
    clone_url = f"https://{token}@github.com/{username}/{repo_name}.git"

    return repo_url, clone_url, username


def push_to_github(project_dir: str, clone_url: str):
    """رفع الكود على GitHub."""
    print("\n📤 رفع الكود على GitHub...")

    # تهيئة Git
    cmds = [
        "git init",
        "git add .",
        'git commit -m "Initial commit: CloakAPI Server v1.0.0" --allow-empty',
        "git branch -M main",
        f"git remote remove origin 2>/dev/null; git remote add origin {clone_url}",
        "git push -u origin main --force",
    ]

    for cmd in cmds:
        code, out, err = run_command(cmd, cwd=project_dir)
        if code != 0 and "nothing to commit" not in err and "already exists" not in err:
            print(f"   ⚠️ {cmd}: {err[:100]}")
        else:
            print(f"   ✅ {cmd.split()[1] if len(cmd.split()) > 1 else cmd}")

    print("   ✅ تم رفع الكود على GitHub!")


def deploy_to_render(github_repo_url: str, render_token: str = None) -> str:
    """
    يوجه المستخدم لنشر الخادم على Render.com.
    إذا كان render_token متوفراً، يتم النشر تلقائياً عبر API.
    """
    print("\n🚀 نشر الخادم على Render.com...")

    if render_token:
        # نشر تلقائي عبر Render API
        headers = {
            "Authorization": f"Bearer {render_token}",
            "Content-Type": "application/json",
        }

        service_data = {
            "type": "web_service",
            "name": "cloakapi-server",
            "repo": github_repo_url,
            "branch": "main",
            "buildCommand": "pip install -r requirements.txt",
            "startCommand": "uvicorn server.main:app --host 0.0.0.0 --port $PORT",
            "plan": "free",
            "envVars": [
                {"key": "PYTHON_VERSION", "value": "3.11.0"},
            ],
            "healthCheckPath": "/health",
        }

        resp = requests.post(
            "https://api.render.com/v1/services",
            headers=headers,
            json=service_data
        )

        if resp.status_code in [200, 201]:
            service = resp.json()
            service_url = service.get("serviceDetails", {}).get("url", "")
            print(f"   ✅ تم النشر! الرابط: https://{service_url}")
            return f"https://{service_url}"
        else:
            print(f"   ⚠️ فشل النشر التلقائي. يرجى النشر يدوياً.")

    # توجيه يدوي
    print("\n" + "="*60)
    print("📋 خطوات النشر اليدوي على Render.com (مجاني ودائم):")
    print("="*60)
    print(f"1. افتح: https://render.com")
    print(f"2. اضغط 'New +' → 'Web Service'")
    print(f"3. اختر 'Connect a repository'")
    print(f"4. اختر المستودع: {github_repo_url}")
    print(f"5. الإعدادات:")
    print(f"   - Name: cloakapi-server")
    print(f"   - Runtime: Python 3")
    print(f"   - Build Command: pip install -r requirements.txt")
    print(f"   - Start Command: uvicorn server.main:app --host 0.0.0.0 --port $PORT")
    print(f"   - Plan: Free")
    print(f"6. اضغط 'Create Web Service'")
    print(f"7. انتظر 2-3 دقائق حتى يكتمل النشر")
    print(f"8. ستحصل على رابط مثل: https://cloakapi-server.onrender.com")
    print("="*60)

    return None


def update_sdk_server_url(project_dir: str, server_url: str):
    """يحدث عنوان الخادم في ملف client.py."""
    client_file = os.path.join(project_dir, "cloak_sdk", "client.py")
    with open(client_file, "r", encoding="utf-8") as f:
        content = f.read()

    content = content.replace(
        'SERVER_URL = os.environ.get("CLOAKAPI_SERVER", "https://cloakapi-server.koyeb.app")',
        f'SERVER_URL = os.environ.get("CLOAKAPI_SERVER", "{server_url}")'
    )

    with open(client_file, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"   ✅ تم تحديث عنوان الخادم في SDK: {server_url}")


def main():
    parser = argparse.ArgumentParser(
        description="CloakAPI Auto-Deploy — رفع الخادم تلقائياً"
    )
    parser.add_argument("--github-token", required=True, help="توكن GitHub")
    parser.add_argument("--repo-name", default="cloakapi-server", help="اسم المستودع")
    parser.add_argument("--render-token", default=None, help="توكن Render (اختياري)")
    parser.add_argument("--server-url", default=None, help="رابط الخادم بعد النشر")

    args = parser.parse_args()

    project_dir = os.path.dirname(os.path.abspath(__file__))

    print("="*60)
    print("🚀 CloakAPI Auto-Deploy")
    print("="*60)

    # 1. إنشاء مستودع GitHub
    repo_url, clone_url, username = create_github_repo(args.github_token, args.repo_name)

    # 2. رفع الكود
    push_to_github(project_dir, clone_url)

    # 3. النشر على Render
    deployed_url = deploy_to_render(repo_url, args.render_token)

    # 4. تحديث SDK إذا كان الرابط معروفاً
    if deployed_url or args.server_url:
        final_url = deployed_url or args.server_url
        update_sdk_server_url(project_dir, final_url)

    print("\n" + "="*60)
    print("✅ اكتملت عملية الرفع!")
    print(f"📦 المستودع: {repo_url}")
    if deployed_url:
        print(f"🌐 الخادم: {deployed_url}")
    print("="*60)


if __name__ == "__main__":
    main()
