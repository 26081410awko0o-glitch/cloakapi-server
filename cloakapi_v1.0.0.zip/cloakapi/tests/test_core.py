"""
اختبارات وحدة CloakAPI — تغطي التشفير، التنفيذ، والأمان.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from cloak_sdk.crypto import CodeEncryptor, APIKeyGenerator
from server.core.security import RateLimiter, APIKeyManager, CodeVault
from server.core.executor import SafeExecutor


def test_encryption():
    """اختبار التشفير وفك التشفير."""
    print("\n[1] اختبار التشفير...")
    encryptor = CodeEncryptor()
    original_code = "def main(**kwargs):\n    return {'result': 42}"

    encrypted, key = encryptor.encrypt(original_code)
    decrypted = encryptor.decrypt(encrypted, key)

    assert decrypted == original_code, "فشل: الكود المفكوك لا يطابق الأصلي!"
    assert encrypted != original_code, "فشل: الكود لم يُشفَّر!"
    print("   ✅ التشفير وفك التشفير يعملان بشكل صحيح.")


def test_api_key_generation():
    """اختبار توليد مفاتيح الـ API."""
    print("\n[2] اختبار توليد المفاتيح...")
    gen = APIKeyGenerator()

    key = gen.generate()
    ep_id = gen.generate_endpoint_id()

    assert key.startswith("cloak_"), f"فشل: المفتاح لا يبدأ بـ 'cloak_': {key}"
    assert ep_id.startswith("ep_"), f"فشل: المعرف لا يبدأ بـ 'ep_': {ep_id}"
    assert len(key) > 20, "فشل: المفتاح قصير جداً!"
    print(f"   ✅ مفتاح مولَّد: {key[:20]}...")
    print(f"   ✅ معرف Endpoint: {ep_id}")


def test_rate_limiter():
    """اختبار Rate Limiter."""
    print("\n[3] اختبار Rate Limiter...")
    limiter = RateLimiter(max_requests=3, window_seconds=60)

    test_key = "test_key_123"

    # الطلبات الثلاثة الأولى يجب أن تُقبل
    for i in range(3):
        allowed, info = limiter.is_allowed(test_key)
        assert allowed, f"فشل: الطلب {i+1} يجب أن يُقبل!"

    # الطلب الرابع يجب أن يُرفض
    allowed, info = limiter.is_allowed(test_key)
    assert not allowed, "فشل: الطلب الرابع يجب أن يُرفض!"
    assert info["remaining"] == 0

    print("   ✅ Rate Limiter يعمل بشكل صحيح.")


def test_code_vault():
    """اختبار خزنة الأكواد."""
    print("\n[4] اختبار Code Vault...")
    vault = CodeVault()

    vault.store("ep_test1", "encrypted_code_here", "key_here", {"name": "test"})

    data = vault.retrieve("ep_test1")
    assert data is not None, "فشل: لم يتم العثور على الكود!"
    assert data["encrypted_code"] == "encrypted_code_here"
    assert data["execution_count"] == 1

    # اختبار الحذف
    vault.delete("ep_test1")
    assert not vault.exists("ep_test1"), "فشل: الكود لم يُحذف!"

    print("   ✅ Code Vault يعمل بشكل صحيح.")


def test_safe_executor():
    """اختبار محرك التنفيذ الآمن."""
    print("\n[5] اختبار Safe Executor...")
    executor = SafeExecutor(timeout_seconds=5)

    # اختبار كود صحيح
    code = """
def main(**kwargs):
    x = kwargs.get('x', 0)
    y = kwargs.get('y', 0)
    return {'sum': x + y, 'product': x * y}
"""
    result = executor.execute(code, {"x": 3, "y": 4})
    assert result["success"], f"فشل: {result['error']}"
    assert result["result"]["sum"] == 7
    assert result["result"]["product"] == 12
    print(f"   ✅ تنفيذ ناجح: {result['result']}")

    # اختبار منع الاستيراد الخطير
    malicious_code = """
import os
def main(**kwargs):
    return os.listdir('/')
"""
    result = executor.execute(malicious_code, {})
    assert not result["success"], "فشل: يجب منع استيراد 'os'!"
    print(f"   ✅ تم منع استيراد 'os' بنجاح.")

    # اختبار منع open()
    malicious_code2 = """
def main(**kwargs):
    with open('/etc/passwd', 'r') as f:
        return f.read()
"""
    result = executor.execute(malicious_code2, {})
    assert not result["success"], "فشل: يجب منع استخدام open()!"
    print(f"   ✅ تم منع استخدام 'open()' بنجاح.")


def run_all_tests():
    """تشغيل جميع الاختبارات."""
    print("="*60)
    print("   CloakAPI — اختبارات الوحدة")
    print("="*60)

    tests = [
        test_encryption,
        test_api_key_generation,
        test_rate_limiter,
        test_code_vault,
        test_safe_executor,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            test()
            passed += 1
        except AssertionError as e:
            print(f"   ❌ {e}")
            failed += 1
        except Exception as e:
            print(f"   ❌ خطأ غير متوقع: {e}")
            failed += 1

    print("\n" + "="*60)
    print(f"النتيجة: {passed} نجح / {failed} فشل")
    print("="*60)
    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
