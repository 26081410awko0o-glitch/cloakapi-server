"""
مثال على سكربت يمكن رفعه كـ API عبر CloakAPI.
يجب أن يحتوي الملف على دالة 'main(**kwargs)' أو 'handler(**kwargs)'.
"""


def main(**kwargs):
    """
    دالة حاسبة بسيطة — مثال توضيحي.
    
    المدخلات المتوقعة:
        x (int/float): الرقم الأول
        y (int/float): الرقم الثاني
        operation (str): العملية (add, subtract, multiply, divide)
    
    المخرجات:
        dict: نتيجة العملية
    """
    x = kwargs.get("x", 0)
    y = kwargs.get("y", 0)
    operation = kwargs.get("operation", "add")

    operations = {
        "add": x + y,
        "subtract": x - y,
        "multiply": x * y,
        "divide": x / y if y != 0 else "لا يمكن القسمة على صفر",
        "power": x ** y,
    }

    if operation not in operations:
        return {
            "error": f"عملية غير معروفة: '{operation}'",
            "available_operations": list(operations.keys())
        }

    result = operations[operation]

    return {
        "success": True,
        "operation": operation,
        "x": x,
        "y": y,
        "result": result,
        "formula": f"{x} {operation} {y} = {result}"
    }
