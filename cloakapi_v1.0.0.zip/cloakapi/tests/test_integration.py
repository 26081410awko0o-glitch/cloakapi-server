"""
اختبار تكاملي كامل لـ CloakAPI — يختبر دورة الحياة الكاملة:
رفع الكود → استدعاء الـ API → التحقق من النتائج → الحذف
"""

import sys
import os
import json
import time
import requests

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

SERVER_URL = "http://localhost:8000"


def test_full_lifecycle():
    """اختبار دورة الحياة الكاملة."""
    print("\n" + "="*60)
    print("   CloakAPI — اختبار تكاملي كامل")
    print("="*60)

    from cloak_sdk.crypto import CodeEncryptor, APIKeyGenerator

    encryptor = CodeEncryptor()
    gen = APIKeyGenerator()

    # ==================== 1. اختبار Health ====================
    print("\n[1] فحص صحة الخادم...")
    resp = requests.get(f"{SERVER_URL}/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "healthy"
    print(f"   ✅ الخادم يعمل بشكل صحيح.")

    # ==================== 2. رفع كود ====================
    print("\n[2] رفع كود Python كـ API...")

    sample_code = """
def main(**kwargs):
    x = kwargs.get('x', 0)
    y = kwargs.get('y', 0)
    operation = kwargs.get('operation', 'add')
    
    if operation == 'add':
        result = x + y
    elif operation == 'multiply':
        result = x * y
    elif operation == 'power':
        result = x ** y
    else:
        return {'error': f'عملية غير معروفة: {operation}'}
    
    return {
        'success': True,
        'result': result,
        'operation': operation,
        'inputs': {'x': x, 'y': y}
    }
"""

    encrypted_code, encryption_key = encryptor.encrypt(sample_code)

    deploy_payload = {
        "encrypted_code": encrypted_code,
        "encryption_key": encryption_key,
        "endpoint_name": "test-calculator",
        "description": "حاسبة اختبار",
        "original_filename": "test_calc.py",
    }

    resp = requests.post(f"{SERVER_URL}/deploy", json=deploy_payload)
    assert resp.status_code == 200, f"فشل الرفع: {resp.text}"

    deploy_data = resp.json()
    assert deploy_data["success"]
    endpoint_id = deploy_data["endpoint_id"]
    api_key = deploy_data["api_key"]
    api_url = deploy_data["api_url"]

    print(f"   ✅ تم الرفع!")
    print(f"   🆔 endpoint_id: {endpoint_id}")
    print(f"   🔑 api_key: {api_key[:25]}...")
    print(f"   🔗 api_url: {api_url}")

    # ==================== 3. استدعاء الـ API ====================
    print("\n[3] استدعاء الـ API...")

    test_cases = [
        {"inputs": {"x": 5, "y": 3, "operation": "add"}, "expected": 8},
        {"inputs": {"x": 4, "y": 6, "operation": "multiply"}, "expected": 24},
        {"inputs": {"x": 2, "y": 10, "operation": "power"}, "expected": 1024},
    ]

    for i, test in enumerate(test_cases, 1):
        resp = requests.post(
            f"{SERVER_URL}/run/{endpoint_id}",
            json={"inputs": test["inputs"]},
            headers={"X-API-Key": api_key}
        )
        assert resp.status_code == 200, f"فشل الاستدعاء {i}: {resp.text}"
        result_data = resp.json()
        assert result_data["success"]
        assert result_data["result"]["result"] == test["expected"], \
            f"نتيجة خاطئة: {result_data['result']['result']} != {test['expected']}"
        print(f"   ✅ اختبار {i}: {test['inputs']} → {result_data['result']['result']}")

    # ==================== 4. اختبار Rate Limiting ====================
    print("\n[4] اختبار Rate Limiting (سيتوقف عند الحد)...")
    # نختبر فقط أن الـ Header موجود
    resp = requests.post(
        f"{SERVER_URL}/run/{endpoint_id}",
        json={"inputs": {"x": 1, "y": 1}},
        headers={"X-API-Key": api_key}
    )
    assert "x-content-type-options" in resp.headers or resp.status_code == 200
    print(f"   ✅ Security Headers موجودة في الاستجابة.")

    # ==================== 5. اختبار مفتاح خاطئ ====================
    print("\n[5] اختبار رفض المفتاح الخاطئ...")
    resp = requests.post(
        f"{SERVER_URL}/run/{endpoint_id}",
        json={"inputs": {}},
        headers={"X-API-Key": "cloak_wrong_key_12345"}
    )
    assert resp.status_code == 401
    print(f"   ✅ تم رفض المفتاح الخاطئ بـ 401 Unauthorized.")

    # ==================== 6. اختبار الإحصاءات ====================
    print("\n[6] جلب إحصاءات الاستخدام...")
    resp = requests.get(
        f"{SERVER_URL}/stats/{endpoint_id}",
        headers={"X-API-Key": api_key}
    )
    assert resp.status_code == 200
    stats = resp.json()
    print(f"   ✅ إجمالي الاستدعاءات: {stats['total_calls']}")

    # ==================== 7. حذف الـ Endpoint ====================
    print("\n[7] حذف الـ Endpoint...")
    resp = requests.delete(
        f"{SERVER_URL}/endpoint/{endpoint_id}",
        headers={"X-API-Key": api_key}
    )
    assert resp.status_code == 200
    print(f"   ✅ تم الحذف بنجاح.")

    # التحقق من الحذف
    resp = requests.post(
        f"{SERVER_URL}/run/{endpoint_id}",
        json={"inputs": {}},
        headers={"X-API-Key": api_key}
    )
    assert resp.status_code in [401, 403, 404]
    print(f"   ✅ الـ Endpoint لم يعد موجوداً (HTTP {resp.status_code}).")

    print("\n" + "="*60)
    print("✅  جميع الاختبارات التكاملية نجحت!")
    print("="*60 + "\n")
    return True


if __name__ == "__main__":
    try:
        test_full_lifecycle()
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ فشل الاختبار: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
